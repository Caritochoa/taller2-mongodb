const mongoose = require("mongoose");
const Schema = mongoose.Schema;

//creacion del esquema y del modelo elenco
const elencoSchema = new Schema({
  nombre: String,
  birth_year: Number,
  pais: String
});

const peliculasSchema = new Schema({
  titulo: String,
  release_year: Number,
  director: String,
  genero: String,
  elenco: [elencoSchema] //array object de objetos elencoSchema
});

const Peliculas = mongoose.model("peliculas", peliculasSchema);

module.exports = Peliculas;
