const mongoose = require("mongoose");

//ES6 Promise
mongoose.promise = global.Promise;

//conectar a la base de datos antes de que test corra

before(function(done) {
  mongoose.connect("mongodb://localhost/movie_db");

  mongoose.connection
    .once("open", function() {
      console.log("Conexion satisfactoria!!!");
      done();
    })
    .on("error", function(error) {
      console.log("Error de conexion", error);
    });
});
