// En este modulo hice testing con mocha
//esto para probar que se estuviera guardando en la db.

const mocha = require("mocha");
const assert = require("assert");
const Peliculas = require("../models/peliculas");

describe("Saving record", function() {
  it("Saves a record to the db", function(done) {
    var char1 = new Peliculas({
      titulo: "Maria Antonieta",
      release_year: 1983,
      director: "Sofia",
      genero: "terror",
      elenco: [
        { nombre: "Pepita Mendieta", nacimiento: 1900, pais: "Francia" },
        { nombre: "Pepe Mendieta", nacimiento: 1901, pais: "Usa" },
        { nombre: "Andres Rodriguez", nacimiento: 1800, pais: "Usa" }
      ]
    });
    char1.save().then(function() {
      assert(char.isNew === false);
      done();
    });
  });
});
